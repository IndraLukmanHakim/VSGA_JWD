<div id="label-page"><h3>Pilihan Beasiswa</h3></div>
<div id="content">
    <div id="container">

    <div class="row">
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">BEASISWA AKADEMIK</h5>
        <p class="card-text">SELEKSI BESISWA BERDASARKAN PRESTASI AKADEMIK</p>
        <!-- <a href="index.php?p=daftar" class="btn btn-primary">DAFTAR</a> -->
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">BEASISWA NON AKADEMIK</h5>
        <p class="card-text">SELEKSI BEASISWA BERDASARKAN PRESTASI NON AKADEMIK</p>
        <!-- <a href="index.php?=daftar" class="btn btn-primary">DAFTAR</a> -->
      </div>
    </div>
  </div>
</div>
    

    </div>
  
</div>
</div>